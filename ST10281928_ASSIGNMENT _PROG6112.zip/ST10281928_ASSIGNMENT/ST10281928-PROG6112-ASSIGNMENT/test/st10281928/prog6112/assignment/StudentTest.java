/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package st10281928.prog6112.assignment;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ndoum
 */
public class StudentTest {
    
    public StudentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        Student.id = new ArrayList<Integer> ();
        Student.id.add(1001);
        Student.id.add(1002);
        Student.id.add(1234);
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of saveStudent method, of class Student.
     */
    @Test
    public void testSaveStudent() {
        System.out.println("saveStudent");
        int studId = 1051;
        String studName = "N.Ndou";
        int studAge = 19;
        String studEmail = "ndoumulisan@gmail.com";
        String studCourse = "BCAD";
        Student.saveStudent(studId, studName, studAge, studEmail, studCourse);
        System.out.println("STUDENT NAME:"+Student.names.get(0));
        System.out.println("STUDENT Id:"+Student.id.get(0));
        System.out.println("STUDENT AGE:"+Student.age.get(0));
        System.out.println("STUDENT EMAIL:"+Student.email.get(0));
        System.out.println("STUDENT COURSE:"+Student.course.get(0));
        
        
        studId = 1001;
         studName = "M.Maseo";
         studAge = 20;
        studEmail = "mmaseo@gmail.com";
        studCourse = "LLB";
        Student.saveStudent(studId, studName, studAge, studEmail, studCourse);
        System.out.println("STUDENT NAME:"+Student.names.get(1));
        System.out.println("STUDENT Id:"+Student.id.get(1));
        System.out.println("STUDENT AGE:"+Student.age.get(1));
        System.out.println("STUDENT EMAIL:"+Student.email.get(1));
        System.out.println("STUDENT COURSE:"+Student.course.get(1));
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of searchStudent method, of class Student.
     */
    @Test
    public void testSearchStudent() {
        System.out.println("searchStudent");
        Student.id = new ArrayList<Integer> ();
        Student.id.add(1001);
        Student.id.add(1002);
        Student.id.add(1234);
        int searchId = 1001;
        Student.searchStudent(searchId);
        Student.searchStudent(searchId);
        boolean found = true;
        for(int i =0;i<Student.id.size();i++){
           if(searchId == Student.id.get(i)){
               found = true;
           }else{
               found = false;
           } 
        }
        System.out.println(Student.id);
        assertTrue(found == true);
        
        
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of deleteStudent method, of class Student.
     */
    @Test
    public void testDeleteStudent() {
        System.out.println("deleteStudent");
       
        int deleteId = 1001;
        Student.deleteStudent(deleteId);
        String answer = "";
        for(int i=0;i< Student.id.size();i++){
            if(deleteId == Student.id.get(i)){
                answer = "Deleted";
            }else{
                answer = "not found";
            }
        }
        System.out.println(Student.id);
        assertTrue(answer.contains("Deleted"));
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of displayStudentReport method, of class Student.
     */
    @Test
    public void testDisplayStudentReport() {
        System.out.println("displayStudentReport");
        Student.displayStudentReport();
        
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
