/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10281928.prog6112.assignment;

import java.util.ArrayList;

/**
 *
 * @author ndoum
 */
public class Student {

    static ArrayList<String> names = new ArrayList<String>();
    static ArrayList<String> email = new ArrayList<String>();
    static ArrayList<String> course = new ArrayList<String>();
    static ArrayList<Integer> age = new ArrayList<Integer>();
    static ArrayList<Integer> id = new ArrayList<Integer>();

    //Code Attribution
    //The code to store values in an arraylist
    //https://stackoverflow.com/questions/43303831/how-to-use-a-method-in-java-to-store-information-from-an-arraylist
    //Vasu
    //https://stackoverflow.com/users/4385895/vasu
    
    public static void saveStudent(int studId, String studName, int studAge, String studEmail, String studCourse) {
        names.add(studName);
        email.add(studEmail);
        course.add(studCourse);
        age.add(studAge);
        id.add(studId);

    }

    //Code attribution
    //The code to search through an arraylist
    //https://stackoverflow.com/questions/20450092/searching-through-arraylist-java
    //Jess Anastasio
    //https://stackoverflow.com/users/2975018/jess-anastasio
    
    public static void searchStudent(int searchId) {
        for (int i = 0; i < id.size(); i++) {
            if (searchId == id.get(i)) {
                System.out.println("-----------------------------");
                System.out.println("STUDENT ID: " + id.get(i));
                System.out.println("STUDENT NAME: " + names.get(i));
                System.out.println("STUDENT AGE: " + age.get(i));
                System.out.println("STUDENT EMAIL: " + email.get(i));
                System.out.println("STUDENT COURSE: " + course.get(i));
                System.out.println("----------------------------");
                break;
            } else {
                System.out.println("-----------------------------");
                System.out.println("Student with Student Id: " + searchId + " was not found !");
                System.out.println("----------------------------");
            }
        }
    }

    public static void deleteStudent(int deleteId) {
        for (int i = 0; i < id.size(); i++) {
            if (deleteId == id.get(i)) {
                id.remove(i);
                names.remove(i);
                age.remove(i);
                email.remove(i);
                course.remove(i);
                System.out.println("-----------------------------");
                System.out.println("Student with Student Id: " + deleteId + " WAS deleted !");
                System.out.println("----------------------------");
                break;
            } else {
                System.out.println("-----------------------------");
              System.out.println("Student with Student Id: "+deleteId+" was not found !");
              System.out.println("----------------------------");
            }
        }
    }

    public static void displayStudentReport() {
        for (int i = 0; i < names.size(); i++) {
            System.out.println("STUDENT" + " " + (i + 1) + "\n-----------------------------");
            System.out.println("STUDENT ID: " + id.get(i));
            System.out.println("STUDENT NAME: " + names.get(i));
            System.out.println("STUDENT AGE: " + age.get(i));
            System.out.println("STUDENT EMAIL: " + email.get(i));
            System.out.println("STUDENT COURSE: " + course.get(i));
            System.out.println("----------------------------");
        }
    }
}
