/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10281928.prog6112.assignment;

import java.util.Scanner;

/**
 *
 * @author ndoum
 */
public class ST10281928PROG6112ASSIGNMENT {

    /**
     * @param args the command line arguments
     */
    static int studId = 0;
    static String studName = "";
    static int studAge = 0;
    static String studEmail = "";
    static String studCourse = "";
    static int searchId = 0;
    static int deleteId = 0;

    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("STUDENT MANAGEMENT APPLICATION"
                + "\n****************************************");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        Scanner input = new Scanner(System.in);
        int menuKey = input.nextInt();
        int menuOption = 0;
        if (menuKey == 1) {
            System.out.println("Please select one of teh following menu items"
                    + "\n(1) Capture new student"
                    + "\n(2) Search for a student"
                    + "\n(3) Delete for a student"
                    + "\n(4) Print student report"
                    + "\n(5) Exit Application");
            menuOption = input.nextInt();
        }
        
        //String answerKey = "";
        while (menuKey == 1 && menuOption !=5) {

            switch (menuOption) {
                case 1:
                    System.out.println("CAPTURE A NEW STUDENT"
                            + "\n***************************************");
                    System.out.print("Enter the student id:");
                    studId = input.nextInt();
                    System.out.print("Enter the student name:");
                    studName = input.next();
                    System.out.print("Enter the student age:");
                    studAge = input.nextInt();
                    while (studAge < 16) {
                        System.out.println("Please enter a age greater than or equal to 16");
                        studAge = input.nextInt();
                    }
                    System.out.print("Enter the student email:");
                    studEmail = input.next();
                    System.out.print("Enter the student course:");
                    studCourse = input.next();
                    Student.saveStudent(studId, studName, studAge, studEmail, studCourse);

                    System.out.println("Enter (1) to launch menu or any other key to exit");
                    menuKey = input.nextInt();
                    break;
                case 2:
                    System.out.print("Enter student id to search: ");
                    searchId = input.nextInt();
                    Student.searchStudent(searchId);
                    System.out.println("Enter (1) to launch menu or any other key to exit");
                    menuKey = input.nextInt();
                    break;
                case 3:
                    System.out.print("Enter student id to delete: ");
                    deleteId = input.nextInt();
                    System.out.print("Are you sure you want to delete " + deleteId + " from the system? Yes (y) to delete: ");
                    String answerKey= input.next();
                    if(answerKey.equalsIgnoreCase("y")){
                        Student.deleteStudent(deleteId);
                    }
                   // Student.deleteStudent(deleteId);
                    System.out.println("Enter (1) to launch menu or any other key to exit");
                    menuKey = input.nextInt();
                    break;
                case 4:
                    Student.displayStudentReport();
                    System.out.println("Enter (1) to launch menu or any other key to exit");
                    menuKey = input.nextInt();
                    break;
                
            }

            System.out.println("Please select one of the following menu items"
                    + "\n(1) Capture new student"
                    + "\n(2) Search for a student"
                    + "\n(3) Delete for a student"
                    + "\n(4) Print student report"
                    + "\n(5) Exit Application");
            menuOption = input.nextInt();

        }

    }

}
