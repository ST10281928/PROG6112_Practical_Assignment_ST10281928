/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10281928.question2.assignment;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 *
 * @author ndoum
 */
public class Member {

    //String [] trainers = {"Jabu Mzekezeke","Samantha Jansen","Jack Doe","Sthembile Dlamini","Petros Mukwevho"};
    protected long idNumber;
    protected int memberNum;
    protected double memberWeight;
    protected double memberHeight;
    protected String memberName;
    protected int memberAge;
    protected String memberGender;
    protected String memberPassword;
    protected String memberEmail;
    protected int memberCell;
    protected String memberPack;
    protected double memberFee;
    protected String userName;
    protected String userPassword;
    protected ArrayList<String> names = new ArrayList<String>();
    protected ArrayList<String>  password= new ArrayList<String>();
    protected ArrayList<Integer>  age= new ArrayList<Integer>();
    protected ArrayList<Double>  weight= new ArrayList<Double>();
    //protected ArrayList<Integer>  age= new ArrayList<Integer>();
    

    Scanner input = new Scanner(System.in);

    public void signUp() {
        System.out.println("*****************Sign Up*****************");
  
        System.out.print("Please enter your name: ");
        memberName = input.next();
        System.out.print("Please enter your Age: ");
        memberAge = input.nextInt();
        System.out.print("Please enter your ID number: ");
        idNumber = input.nextLong();
        System.out.print("Please enter your Gender (Male/Female): ");
        memberGender = input.next();
        System.out.print("Please enter your Weight (kg): ");
        memberWeight = input.nextDouble();
        System.out.print("Please enter your Height: ");
        memberHeight = input.nextDouble();
        System.out.print("Please enter your preferred membership package: ");
        memberPack = input.next();
        switch(memberPack){
            case "Bronze":
                memberFee = 99.00;
            case "Silver":
                memberFee = 189.00;
            case "Gold":
                 memberFee = 279.00;
            default:
                memberFee = 99.00;
        }
        System.out.print("Please create your password, Make sure it is longer than 8 and has atleast one special character, a capital letter and one number: ");
        memberPassword = input.next();
        while(checkPasswordComplexity()==false){
          System.out.print("Please create your password, Make sure it is longer than 8 and has atleast one special character, a capital letter and one number: ");
        memberPassword = input.next();  
        }
        names.add(memberName);
        password.add(memberPassword);
        String output ="====================================";
        output=String.format("%-15s  %-15s  %-15s",("NAME: "+memberName),("AGE: "+memberAge),("GENDER: "+memberGender));
        output+="\n";
        output+=String.format("%-15s  %-15s  ",("ID NUMBER: "+idNumber),("PACKAGE: "+memberPack));
        output+="\n";
        output+=String.format("%-15s","Password: "+memberPassword);
        System.out.println(output);
    }
    
     //Code Attribution
    //The code to check for special characters
    //https://stackoverflow.com/questions/1795402/check-if-a-string-contains-a-special-character
    //Reilas
    //https://stackoverflow.com/users/17758716/reilas
    
    public  boolean checkPasswordComplexity() {
            return memberPassword.length() >= 8 && memberPassword.matches(".*[A-Z].*") && memberPassword.matches(".*[0-9].*") && memberPassword.matches(".*?[" + Pattern.quote("!@#$%^&*()_-+=[]{};:'<>,.?|/") + "].*");
        }

    public void login() {
        System.out.println("*****************Login*****************");
        System.out.print("Please enter your name: ");
        userName = input.next();
        System.out.print("Please enter your password: ");
        userPassword = input.next();
    }
    public boolean checkUser(){
        int indexName = 0 ;
        for(int i =0;i<names.size();i++){
            if(userName.equals(names.get(i))){
                indexName = i;
                
                if(userPassword.equals(password.get(indexName))){
                    return true;
                }
            }
        }
        return false;
    }
    
    public void profile(){
        System.out.println("*****************Profile*****************");
        String output = String.format("%-15s %-15s %-15s",("Name :"+memberName),("Age: "+memberAge),("Package: "+memberPack));
        output+="\n";
        output+=String.format("%-15s %-15s ",("Weight :"+memberWeight),("Height: "+memberHeight));
        System.out.println(output);
    }
    
    public void progress(){
        Scanner input = new Scanner(System.in);
        int[] gymTracker = new int[3];
        System.out.println("How many times did you go to the gym in Jan?");
        gymTracker[0] = input.nextInt();
        System.out.println("How many times did you go to the gym in Feb?");
         gymTracker[1] = input.nextInt();
         System.out.println("How many times did you go to the gym in Mar?");
         gymTracker[2] = input.nextInt();
      
         
         String display = "***********************PROGRESS REPORT********************";
         display+="\n";
         display+=String.format("%-15s %-15s %-15s", "Jan","Feb","Mar");
         display+="\n";
         display+=String.format("%-15s %-15s %-15s", gymTracker[0],gymTracker[1],gymTracker[2]);
         display+="\n";
         System.out.println(display);
    }
    
    public void workouts(){
        System.out.println("*****************Workouts*****************");
        System.out.println("These are the following workouts:");
        System.out.println("Cardio:\n"
                + "Mountain Climbers\n"
                + "Jumping Jacks\n"
                + "Burpees");
        System.out.println("Chest:\n"
                + "Push-ups\n"
                + "Plank Shoulder Taps\n"
                + "Diamond Push-ups");
        System.out.println("Arms:\n"
                + "Tricep dip\n"
                + "Plank\n"
                + "Lateral Raises" 
                );
        System.out.println("Shoulders:\n"
                + "Pike press\n"
                + "Dumbbell shrugg\n"
                + "Push press" 
                );
        System.out.println("Core:\n"
                + "Sit ups\n"
                + "Plank\n"
                + "Leg raises" 
                );
        System.out.println("Legs:\n"
                + "Squats\n"
                + "Donkey kicks\n"
                + "Calf Raises" 
                );
    }
    
    
    
    
    
}
