/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10281928.question2.assignment;

/**
 *
 * @author ndoum
 */
public class Bronzepack extends Member {
    
    public void descriptionBronze(){
        System.out.println("This is a pay-as-you-go package where you will only pay for every month that you use it ");
    }
}
