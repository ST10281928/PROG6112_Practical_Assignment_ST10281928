/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10281928.question2.assignment;

import java.util.Scanner;
/**
 *
 * @author ndoum
 */

//Code attribution
//The code on how to use inheritance
//https://stackoverflow.com/questions/3990093/java-inheritance
//Menuka Ishan &user483315
//https://stackoverflow.com/users/2940265/menuka-ishan
//https://stackoverflow.com/users/483315/user483315
public class Goldpack extends Member {
    
    String [] trainers = {"Jabu Mzekezeke","Samantha Jansen","Jack Doe","Sthembile Dlamini","Petros Mukwevho"};
    
    public void trainers(){
        System.out.println("These are our Personal Trainers; ");
        for(int i=0;i<trainers.length;i++){
            System.out.println("Personal Trainer "+(i+1)+": "+trainers[i]);
        }
        
    }
    public void mealPlan(){
        System.out.println("*****************Meal Plan*****************");
        System.out.println("Here are the Diets we have, choose which one you like");
        System.out.println("(1) Keto Diet\n(2) Atkins Diet\n(3) Low Carbohydrate Diet");
        Scanner input = new Scanner(System.in);
        int dietOpt = input.nextInt();
        System.out.println("Your diet is "+dietOpt);
    }
    //Code attribution
    //The code on how to use String.format
    //https://stackoverflow.com/questions/22416578/how-to-use-string-format-in-java
    //Lemmy301
    //https://stackoverflow.com/users/3397696/lemmy301
    
    public void customWorkout(){
        Scanner input = new Scanner(System.in);
        String [] workoutPlan =new String [6];
        
        System.out.println("*****************Custom Workout*****************");
        String output= "Cardio";
        output+="\n";
        output += String.format(" %-15s %-15s %-15s ", "(1)Mountain Climber","(2)Jumping Jacks","(3)Burpees");
        output+="\n";
        output+= "Chest";
        output+="\n";
        output += String.format(" %-15s %-15s %-15s ", "(1)Push ups","(2)Incline push ups","(3)Pike push ups");
        output+="\n";
        output+= "Arms";
        output+="\n";
        output += String.format(" %-15s %-15s %-15s ", "(1)Dumbbell curls","(2)Tricep dips","(3)Tricep Extension");
        output+="\n";
        output+= "Shoulders";
        output+="\n";
        output += String.format(" %-15s %-15s %-15s ", "(1)Lateral raises","(2)Plank Shoulder taps","(3)Pike push ups");
        output+="\n";
        output+= "Core";
        output+="\n";
        output += String.format(" %-15s %-15s %-15s ", "(1)Sit ups","(2)Leg raises","(3)Plank");
        output+="\n";
        output+= "Legs";
        output+="\n";
        output += String.format(" %-15s %-15s %-15s ", "(1)Squats","(2)Bulgarian squats","(3)Calf raises");
        output+="\n";
        System.out.println(output);
        System.out.println("Choose one from each and we will print out a full body workout");
   
        for(int i = 0;i<workoutPlan.length;i++){
            workoutPlan[i] = input.nextLine();
        }
        System.out.println("*****************Your Workout*****************");
        for(int j = 0;j<workoutPlan.length;j++){
            System.out.print(workoutPlan[j]+"             ");
        }
        System.out.println("\n\n");
        String workoutDisplay=String.format(" %-10s %-10s %-10s %-10s %-10s %-10s","x3(30sec)","x3(x12)","x3(x12)","x3(x12)","x3(x12)","x3(x12)" );
        System.out.println(workoutDisplay);
    }
    
}
