/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10281928.question2.assignment;
import java.util.Scanner;
/**
 *
 * @author ndoum
 */
public class Silverpack extends Member {
    
    public void sessions(){
        String[] sessionTrainer = {"Jabu Mzekezeke","Jack Doe","Petros Mukwevho","Sthembile Dlamini","Jabu Mzekezeke","Petros Mukwevho"};
        int [] sessionCalendar = {9,10,11,12,13,14};
        System.out.println("***********************Todays Session*************************");
            System.out.println("Trainer: "+sessionTrainer[0]+"\n"
                    + "Date: September "+sessionCalendar[0]);

    }
}
