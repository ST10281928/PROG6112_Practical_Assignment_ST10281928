/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10281928.question2.assignment;

import java.util.Scanner;

/**
 *
 * @author ndoum
 */
public class ST10281928QUESTION2ASSIGNMENT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("************* WELCOME TO ABC GYM *************");
        System.out.println("(1) REGISTER/SIGN-UP \n(2) LOGIN");
        Scanner input = new Scanner(System.in);
        int option = input.nextInt();
        int option1 = 0;
        Member obj = new Member();
        while (option == 1) {
            obj.signUp();
            System.out.println("Enter any key to go back to menu");
            option = input.nextInt();
        }
        System.out.println("************* WELCOME TO ABC GYM *************");
        System.out.println("(1) REGISTER/SIGN-UP \n(2) LOGIN");
        option = input.nextInt();
        // option1 = 0;
        if (option == 2) {
            obj.login();
            obj.checkUser();
            while (obj.checkUser() == false) {
                obj.login();
            }
            System.out.println("(1) PROFILE \n(2) Progression TRACKER \n(3) WORKOUTS  \n(4) CLASSES/SESSION(COACHING) \n(5) Meal Plan \n(6) Exit");
            option1 = input.nextInt();
        }

        Goldpack obj1 = new Goldpack();
        Silverpack obj2 = new Silverpack();
        
        while (option == 2) {
            switch (option1) {
                case 1:
                    obj.profile();
                    break;
                case 2:
                    obj.progress();
                    break;
                case 3:
                    if (obj.memberPack.equalsIgnoreCase("Bronze") && obj.memberPack.equalsIgnoreCase("Silver")) {
                        obj.workouts();
                    }
                    obj1.customWorkout();
                    break;
                case 4:
                    if(obj.memberPack.equalsIgnoreCase("Bronze")){
                        System.out.println("You need to upgrade fo these feature");
                    }
                    obj2.sessions();
                    break;
                case 5:
                    obj1.mealPlan();
                    break;
                case 6:
                    option+=2;
                    break;
                default:
                    System.out.println("Invalid input please try again");
            }
            System.out.println("(1) PROFILE \n(2) Progression TRACKER \n(3) WORKOUTS  \n(4) CLASSES/SESSION(COACHING \n(5) Meal Plan \n(6) Exit");
            option1 = input.nextInt();

        }
    }

}
