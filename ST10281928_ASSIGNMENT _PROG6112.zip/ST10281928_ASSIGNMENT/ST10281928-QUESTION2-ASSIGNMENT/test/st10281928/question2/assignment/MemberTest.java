/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package st10281928.question2.assignment;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ndoum
 */
public class MemberTest {
    
    public MemberTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
       
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of signUp method, of class Member.
     */
    @Test
    public void testSignUp() {
        System.out.println("signUp");
        Member instance = new Member();
        instance.memberName="Ndivhuwo";
        instance.memberAge=19;
        instance.memberGender="Male";
        instance.idNumber=465820477;
        instance.memberPack="Bronze";
        instance.signUp();
        
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of checkPasswordComplexity method, of class Member.
     */
    @Test
    public void testCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        Member instance = new Member();
        instance.memberPassword ="Ndvhuwo";
        boolean expResult = false;
        boolean result = instance.checkPasswordComplexity();
        assertEquals(expResult, result);
        
        instance.memberPassword ="Nd1vhuwo@";
        boolean expResult2 = true;
        boolean result2 = instance.checkPasswordComplexity();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of login method, of class Member.
     */
    @Test
    public void testLogin() {
        System.out.println("login");
        Member instance = new Member();
        
        instance.login();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of checkUser method, of class Member.
     */
    @Test
    public void testCheckUser() {
        System.out.println("checkUser");
        Member instance = new Member();
        instance.names.add("Ndivhuwo");
        instance.names.add("Junior");
        instance.names.add("Tival");
        instance.password.add("Nd1vhuw@");
        instance.password.add("Nd2vhuw#");
        instance.password.add("Do1vhuw@");
        instance.userName="Junior";
        instance.userPassword="Nd2vhuw#";
        boolean expResult = true;
        boolean result = instance.checkUser();
        assertEquals(expResult, result);
        
        instance.names.add("Ndivhuwo");
        instance.names.add("Junior");
        instance.names.add("Tival");
        instance.password.add("Nd1vhuw@");
        instance.password.add("Nd2vhuw#");
        instance.password.add("Do1vhuw@");
        instance.userName="Junior";
        instance.userPassword="Nd09vhuw#";
        boolean expResult2 = false;
        boolean result2 = instance.checkUser();
        assertEquals(expResult2, result2);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of profile method, of class Member.
     */
    @Test
    public void testProfile() {
        System.out.println("profile");
        Member instance = new Member();
        instance.names.add("Ndivhuwo");
         instance.password.add("Nd1vhuw@");
         
        instance.profile();
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of progress method, of class Member.
     */
    @Test
    public void testProgress() {
        System.out.println("progress");
        Member instance = new Member();
        instance.progress();
        
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of workouts method, of class Member.
     */
    @Test
    public void testWorkouts() {
        System.out.println("workouts");
        Member instance = new Member();
        instance.workouts();
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }
    
}
