/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package st10281928.question2.assignment;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ndoum
 */
public class GoldpackTest {
    
    public GoldpackTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of trainers method, of class Goldpack.
     */
    @Test
    public void testTrainers() {
        System.out.println("trainers");
        Goldpack instance = new Goldpack();
        instance.trainers();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of mealPlan method, of class Goldpack.
     */
    @Test
    public void testMealPlan() {
        System.out.println("mealPlan");
        Goldpack instance = new Goldpack();
        instance.mealPlan();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of customWorkout method, of class Goldpack.
     */
    @Test
    public void testCustomWorkout() {
        System.out.println("customWorkout");
        Goldpack instance = new Goldpack();
        instance.customWorkout();
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }
    
}
